package com.springrest.LDManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LdManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LdManagementApplication.class, args);
	}

}
