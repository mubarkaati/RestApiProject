package com.springrest.LDManagement.model.DTO;

public class FeedbackDto {
}
